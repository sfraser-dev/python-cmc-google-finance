from .model_list import ModelList
from .data_mixin import DataMixin


class DataList(DataMixin, ModelList):
    pass
